__version__ = '0.6.0'
import os
import sys
exeDir = os.path.abspath(os.path.dirname(__file__))+os.sep
