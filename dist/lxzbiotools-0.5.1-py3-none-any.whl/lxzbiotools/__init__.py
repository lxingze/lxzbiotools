__version__ = '0.5.1'
import os
import sys
exeDir = os.path.abspath(os.path.dirname(__file__))+os.sep
