__version__ = '0.5.5'
import os
import sys
exeDir = os.path.abspath(os.path.dirname(__file__))+os.sep
